import java.util.Random;

public class UniqueRandom {
    public static void main(String[] args) {
        Random random = new Random();
        int[] number = new int[10];
        int count = 0;                         // how many unique values are stored

        while (count < 10) {
            int candidate = random.nextInt(21);  // 0 to 20

            boolean duplicate = false;           // linear search of the stored values
            for (int i = 0; i < count; i++) {
                if (number[i] == candidate) {
                    duplicate = true;
                    break;
                }
            }

            if (!duplicate) {                    // keep it; otherwise draw again
                number[count] = candidate;
                count++;
            }
        }

        System.out.println("10 non-duplicate random integers within 0 to 20");
        for (int i = 0; i < number.length; i++) {
            System.out.print(number[i] + (i < number.length - 1 ? ", " : "\n"));
        }
    }
}
