import java.util.Random;
import java.util.Scanner;

public class ScoreList {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        Random random = new Random();

        System.out.print("Enter the number of students: ");
        int n = keyboard.nextInt();
        if (n <= 0) {
            System.out.println("The number of students must be at least 1.");
            return;
        }

        int[] score = new int[n];
        for (int i = 0; i < n; i++) {
            score[i] = random.nextInt(101);   // 0 to 100
        }

        System.out.println("List of scores");
        for (int i = 0; i < n; i++) {
            System.out.print(score[i] + (i < n - 1 ? ", " : "\n"));
        }

        int highest = score[0], lowest = score[0];   // start from a real score, not 0
        int sum = 0;
        for (int i = 0; i < n; i++) {
            if (score[i] > highest) {
                highest = score[i];
            }
            if (score[i] < lowest) {
                lowest = score[i];
            }
            sum += score[i];
        }

        System.out.println("Highest score: " + highest);
        System.out.println("Lowest score: " + lowest);
        System.out.printf("Average score: %.2f%n", (double) sum / n);
    }
}
