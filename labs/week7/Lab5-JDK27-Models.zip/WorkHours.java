import java.util.Random;
import java.util.Scanner;

public class WorkHours {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        Random random = new Random();

        System.out.print("Enter the number of employees: ");
        int n = keyboard.nextInt();
        if (n <= 0) {
            System.out.println("The number of employees must be at least 1.");
            return;
        }

        int[][] hours = new int[n][7];           // one row per employee, one column per day
        for (int e = 0; e < n; e++) {
            for (int d = 0; d < 7; d++) {
                hours[e][d] = random.nextInt(8) + 1;   // 1 to 8 hours
            }
        }

        String[] day = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        System.out.printf("%-10s", "Employee");
        for (int d = 0; d < 7; d++) {
            System.out.printf("%5s", day[d]);
        }
        System.out.printf("%7s%n", "Total");

        for (int e = 0; e < n; e++) {
            int total = 0;                       // reset for each employee
            System.out.printf("%-10s", "Emp " + (e + 1));
            for (int d = 0; d < 7; d++) {
                System.out.printf("%5d", hours[e][d]);
                total += hours[e][d];
            }
            System.out.printf("%7d%n", total);
        }
    }
}
