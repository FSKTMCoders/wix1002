import java.util.Scanner;

public class PascalMatrix {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter the number of row of Pascal Triangle to generate: ");
        int n = keyboard.nextInt();
        if (n < 1) {
            System.out.println("The number of rows must be at least 1.");
            return;
        }

        int[][] pascal = new int[n][n];          // every element starts at 0
        for (int r = 0; r < n; r++) {
            for (int c = 0; c <= r; c++) {       // only on or below the diagonal
                if (c == 0 || c == r) {
                    pascal[r][c] = 1;            // first column and diagonal
                } else {
                    pascal[r][c] = pascal[r - 1][c - 1] + pascal[r - 1][c];
                }
            }
        }

        System.out.println("The Pascal Triangle with " + n + " row(s)");
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                System.out.printf("%-4d", pascal[r][c]);
            }
            System.out.println();
        }
    }
}
