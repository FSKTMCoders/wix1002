WIX1002 Week 7 · Lab 5: Arrays · JDK 27 models

Compile and run each program from this folder, for example:
  javac --release 27 ScoreList.java
  java ScoreList

Files:
  PascalMatrix.java
  RotateMatrix.java
  ScoreList.java
  SearchCompare.java
  UniqueRandom.java
  WorkHours.java

The models assume numeric input of the requested type and use no preview features.
