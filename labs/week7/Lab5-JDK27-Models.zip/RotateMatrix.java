public class RotateMatrix {
    public static void main(String[] args) {
        int[][] matrix = {
            {1, 5, 7},
            {3, 6, 9},
            {5, 3, 8}
        };
        int n = matrix.length;

        System.out.println("3 by 3 Matrix");
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                System.out.print(matrix[r][c] + (c < n - 1 ? " " : "\n"));
            }
        }

        // Row r of the result is column r of the original, read from the bottom up.
        int[][] rotated = new int[n][n];
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                rotated[r][c] = matrix[n - 1 - c][r];
            }
        }

        System.out.println("After rotates 90 degrees clockwise");
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                System.out.print(rotated[r][c] + (c < n - 1 ? " " : "\n"));
            }
        }
    }
}
