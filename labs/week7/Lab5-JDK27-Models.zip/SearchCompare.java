import java.util.Random;
import java.util.Scanner;

public class SearchCompare {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner keyboard = new Scanner(System.in);

        int[] a = new int[20];
        for (int i = 0; i < a.length; i++) {
            a[i] = random.nextInt(101);          // 0 to 100
        }
        System.out.println("A list of 20 random integer within 0 to 100");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + (i < a.length - 1 ? ", " : "\n"));
        }

        // Bubble sort in descending order: move the smaller value to the right.
        for (int pass = 1; pass < a.length; pass++) {
            for (int i = 0; i < a.length - pass; i++) {
                if (a[i] < a[i + 1]) {
                    int hold = a[i];
                    a[i] = a[i + 1];
                    a[i + 1] = hold;
                }
            }
        }
        System.out.println("Array in descending order");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + (i < a.length - 1 ? ", " : "\n"));
        }

        System.out.print("Enter a number to search: ");
        int key = keyboard.nextInt();

        // Linear search: count every element compared, including the match.
        int linearLoops = 0;
        boolean linearFound = false;
        for (int i = 0; i < a.length; i++) {
            linearLoops++;
            if (a[i] == key) {
                linearFound = true;
                break;
            }
        }
        System.out.println(key + (linearFound ? " found" : " not found"));
        System.out.println("Linear Search - " + linearLoops + " loop(s)");

        // Binary search on a descending array: larger values are on the left.
        int low = 0, high = a.length - 1, binaryLoops = 0;
        boolean binaryFound = false;
        while (low <= high) {
            binaryLoops++;
            int middle = (low + high) / 2;
            if (a[middle] == key) {
                binaryFound = true;
                break;
            } else if (key > a[middle]) {
                high = middle - 1;               // key is further left
            } else {
                low = middle + 1;                // key is further right
            }
        }
        System.out.println(key + (binaryFound ? " found" : " not found"));
        System.out.println("Binary Search - " + binaryLoops + " loop(s)");
    }
}
