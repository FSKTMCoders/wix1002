import java.util.Scanner;

public class MultiPrint {
    // Precondition: none; nothing is printed when n <= 0.
    // Postcondition: prints n copies of c on the current line, without a line break.
    public static void multiPrint(int n, char c) {
        for (int i = 0; i < n; i++) {
            System.out.print(c);
        }
    }

    // Precondition: size >= 1.
    // Postcondition: prints a right-angled triangle; row r has r stars.
    public static void rightTriangle(int size) {
        for (int row = 1; row <= size; row++) {
            multiPrint(row, '*');
            System.out.println();
        }
    }

    // Precondition: size >= 1.
    // Postcondition: prints a centred triangle; row r has size - r spaces and 2r - 1 stars.
    public static void centredTriangle(int size) {
        for (int row = 1; row <= size; row++) {
            multiPrint(size - row, ' ');
            multiPrint(2 * row - 1, '*');
            System.out.println();
        }
    }

    // Precondition: size >= 1.
    // Postcondition: prints a diamond 2 * size - 1 rows high: the centred triangle,
    //                then the same rows upside down without repeating the widest row.
    public static void diamond(int size) {
        centredTriangle(size);
        for (int row = size - 1; row >= 1; row--) {
            multiPrint(size - row, ' ');
            multiPrint(2 * row - 1, '*');
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter the size: ");
        int size = keyboard.nextInt();
        if (size < 1) {
            System.out.println("The size must be at least 1.");
            return;
        }

        System.out.println("Triangle");
        rightTriangle(size);
        System.out.println("Centred triangle");
        centredTriangle(size);
        System.out.println("Diamond");
        diamond(size);
    }
}
