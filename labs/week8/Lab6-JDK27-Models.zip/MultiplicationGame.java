import java.util.Random;
import java.util.Scanner;

public class MultiplicationGame {
    // Precondition: none.
    // Postcondition: returns true when answer is equal to first * second.
    public static boolean isCorrect(int first, int second, int answer) {
        return answer == first * second;
    }

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        Random random = new Random();
        int score = 0;

        while (true) {
            int first = random.nextInt(13);    // 0 to 12
            int second = random.nextInt(13);
            System.out.println("Enter negative number to quit.");
            System.out.print(first + " x " + second + " = ");
            int answer = keyboard.nextInt();
            if (answer < 0) {
                break;                         // a negative answer ends the game
            }
            if (isCorrect(first, second, answer)) {
                score++;
            }
        }
        System.out.println("Your Score is " + score);
    }
}
