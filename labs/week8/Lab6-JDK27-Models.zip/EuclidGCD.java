public class EuclidGCD {
    // Precondition: a > 0 and b > 0.
    // Postcondition: returns the greatest common divisor of a and b.
    public static int gcd(int a, int b) {
        while (b != 0) {
            int remainder = a % b;
            a = b;
            b = remainder;
        }
        return a;
    }

    public static void main(String[] args) {
        System.out.println("GCD(24, 8) = " + gcd(24, 8));
        System.out.println("GCD(200, 625) = " + gcd(200, 625));
    }
}
