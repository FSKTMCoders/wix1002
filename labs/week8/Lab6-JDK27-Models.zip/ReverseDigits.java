import java.util.Random;

public class ReverseDigits {
    // Precondition: number >= 0 and its reverse fits in an int.
    // Postcondition: returns the digits of number in reverse order (1234 -> 4321, 1200 -> 21, 0 -> 0).
    public static int reverse(int number) {
        int reversed = 0;
        while (number > 0) {
            reversed = reversed * 10 + number % 10;   // append the last digit
            number /= 10;                             // remove the last digit
        }
        return reversed;
    }

    // Precondition: numbers has 10 elements, each meeting the precondition of reverse.
    // Postcondition: every element is replaced by its reverse. The caller's array changes,
    //                because the method receives a copy of the reference to the same array.
    public static void reverseAll(int[] numbers) {
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = reverse(numbers[i]);
        }
    }

    // Postcondition: prints the label and the elements on one line.
    public static void printArray(String label, int[] numbers) {
        System.out.print(label + ":");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(" " + numbers[i]);
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Random random = new Random();
        int[] numbers = new int[10];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(10000);   // 0 to 9999
        }

        printArray("Before", numbers);
        reverseAll(numbers);                       // no return value: the array itself changes
        printArray("After ", numbers);
    }
}
