WIX1002 Week 8 · Lab 6: Java Methods · JDK 27 models

Compile and run each program from this folder, for example:
  javac --release 27 TriangularNumbers.java
  java TriangularNumbers

Files:
  EuclidGCD.java
  MultiPrint.java
  MultiplicationGame.java
  PalindromicPrimeEmirp.java
  ReverseDigits.java
  TriangularNumbers.java

The models assume numeric input of the requested type and use no preview features.
