public class TriangularNumbers {
    // Precondition: n >= 1.
    // Postcondition: returns the nth triangular number, 1 + 2 + ... + n.
    public static int triangular(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }

    public static void main(String[] args) {
        System.out.println("The first 20 triangular numbers");
        for (int n = 1; n <= 20; n++) {
            System.out.printf("%5d", triangular(n));
            if (n % 10 == 0) {
                System.out.println();
            }
        }
    }
}
