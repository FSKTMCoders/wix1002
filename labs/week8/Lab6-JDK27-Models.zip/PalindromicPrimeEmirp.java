public class PalindromicPrimeEmirp {
    // Precondition: none.
    // Postcondition: returns true when number is prime (greater than 1, no divisor from 2 to its square root).
    public static boolean isPrime(int number) {
        if (number < 2) {
            return false;
        }
        for (int divisor = 2; divisor * divisor <= number; divisor++) {
            if (number % divisor == 0) {
                return false;
            }
        }
        return true;
    }

    // Precondition: number >= 0.
    // Postcondition: returns the digits of number in reverse order.
    public static int reverse(int number) {
        int reversed = 0;
        while (number > 0) {
            reversed = reversed * 10 + number % 10;
            number /= 10;
        }
        return reversed;
    }

    // Precondition: number >= 0.
    // Postcondition: returns true when number reads the same backwards.
    public static boolean isPalindrome(int number) {
        return number == reverse(number);
    }

    // Postcondition: returns true when number is both prime and a palindrome.
    public static boolean isPalindromicPrime(int number) {
        return isPrime(number) && isPalindrome(number);
    }

    // Postcondition: returns true when number is prime, its reverse is prime,
    //                and it is not a palindromic prime.
    public static boolean isEmirp(int number) {
        return isPrime(number) && isPrime(reverse(number)) && !isPalindromicPrime(number);
    }

    public static void main(String[] args) {
        System.out.println("The first 20 palindromic primes");
        int count = 0;
        for (int number = 2; count < 20; number++) {
            if (isPalindromicPrime(number)) {
                count++;
                System.out.printf("%6d", number);
                if (count % 10 == 0) {
                    System.out.println();
                }
            }
        }

        System.out.println("The first 20 emirps");
        count = 0;
        for (int number = 2; count < 20; number++) {
            if (isEmirp(number)) {
                count++;
                System.out.printf("%6d", number);
                if (count % 10 == 0) {
                    System.out.println();
                }
            }
        }
    }
}
