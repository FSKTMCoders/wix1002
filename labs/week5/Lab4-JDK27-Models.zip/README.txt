WIX1002 Week 5 · Lab 4: Flow of Control (Repetition) · JDK 27 models

Compile and run each program from this folder, for example:
  javac --release 27 Factors.java
  java Factors

Files:
  DiceRace.java
  DigitCount.java
  Factors.java
  FirstPrimes.java
  MayAugustCalendar.java
  MortgageTable.java
  ScoreStatistics.java
  SeriesSum.java

The models assume numeric input of the requested type and use no preview features.
