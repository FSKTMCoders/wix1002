WIX1002 Week 4 · Lab 3: Flow of Control (Selection) · JDK 27 models

Compile and run each program from this folder, for example:
  javac --release 27 SimpleCalculator.java
  java SimpleCalculator

Files:
  CramersRule.java
  DiceGame.java
  NumberInWords.java
  PointInCircle.java
  SalesCommission.java
  SimpleCalculator.java

The models assume numeric input of the requested type and use no preview features.
